package com.bham.pij.assignments.a2a;
import java.util.ArrayList;
import java.util.Collections;
import java.lang.Math;

public class Maths {
    /*
    public static void main(String[] args) {
        System.out.println("Hello world");

    }
    */
}
