package com.bham.pij.assignments.a2a;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Collections;
public class Individual {

    private ArrayList<Character> populationbinary;
    BinaryMaximiser individual = new BinaryMaximiser();
    FinalVariables start = new FinalVariables();

    // BinaryMaximiser

    // method to convert charactes to strings

    BinaryMaximiser[] individualGene = new BinaryMaximiser[start.numberOfChromosomes];
    public String[] individuals = new String[start.numberOfChromosomes];
    public Individual() {
        // BinaryMaximiser[] individualGene = new BinaryMaximiser[start.numberOfChromosomes];
        for (int i = 0; i < start.numberOfChromosomes; i++) {
            individualGene[i] = new BinaryMaximiser(individual.generatedsize);
        }
        for (int j = 0; j < start.numberOfChromosomes; j++) {
            individuals[j] = toString(individualGene[j].gene);
        }
    }
    public Individual(int i) {
        this.individuals[i] = individuals[i];
    }

    public boolean IsItBinary() {
        boolean isItBinary = false;
        for (int i = 0; i < individualGene[i].gene.size(); i++) {
            char whatIsTheCharacter = individualGene[i].gene.get(i);
            if (whatIsTheCharacter != '0' && whatIsTheCharacter != '1') {
                isItBinary = false;
            } else {
                isItBinary = true;
            }
        }
        return isItBinary;
    }
    private static String toString(ArrayList<Character> list) {
        // initialsises the string
        String convertedString = "";
        // for loop to run through the characters
        for (int i = 0; i < list.size(); i++) {
            // gets the character form the string
            char charToString = list.get(i);
            // creats the string
            convertedString = convertedString + charToString;
        }
        // finishes the method
        return convertedString;
    }
    protected double getFitness() {
        double fitnessdouble = 0;
        if (IsItBinary() == true) {
            for (int i = 0; i < individualGene[i].gene.size(); i++) {
                char currentChar = individualGene[i].gene.get(i);
                if (currentChar == '1') {
                    fitnessdouble = fitnessdouble + 1;
                }
            }
        }
        /*
        if (IsItBinary() == false) {
            double fitnessdouble = 0;

            ArrayList<Integer> list = new ArrayList<Integer>();

            for (int i = 0; i < targetedString.length(); i++) {

                char targetStringCompare = targetedString.charAt(i);
                // finds the character at position i of the current string
                char currentStringCompare = individualGene[i].charAt(i);
                // takes away the the targetstirng character from the final string character
                int charoperation = targetStringCompare - currentStringCompare;
                // makes sure the average value is above 0
                int averageChar = Math.abs(charoperation);
                // adds value to a list to later work out average
                list.add(averageChar);
            }
        }
        */

        return fitnessdouble;
    }

}
