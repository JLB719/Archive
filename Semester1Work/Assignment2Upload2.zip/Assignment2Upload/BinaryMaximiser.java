package com.james.a2a;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Collections;
// need to sort out this constructor
public class BinaryMaximiser extends GAApplication {
    Individual individuals = new Individual();
    FinalVariables store = new FinalVariables();
    private ArrayList<Character> binaryList;
    protected ArrayList<Character> gene;
    protected int generatedsize;
    private String binary;
    // creates the final chromosoems size
    @Override
    protected int determine() {
        int returnValue = 1;
        return 1;
    }
    public BinaryMaximiser(int size) {
        String binary = "";
        for (int i = 0; i < generatedsize; i++) {
            binary = binary + "1";
        }
        generatedsize = size;
    }

    public BinaryMaximiser() {

        int sizeofIndividual = generatedsize;

        ArrayList<Character> generationbinary = new ArrayList<Character>();
        //char[] generation = new char[size];
        for (int i = 0; i < generatedsize; i++) {
        double randomgenerator = Math.random();

            if (randomgenerator < 0.5) {
                generationbinary.add('0');
            }
            if (randomgenerator >= 0.5) {
                generationbinary.add('1');
            }
        }
        gene = generationbinary;
    }


    // overides the getFitness method
    @Override
    // method to find fitness
    protected double getFitness(String currentString) {
        // intiailes the count for ones
        int onecount = 0;
        // for loop to work cycle through the string
        for (int i = 0; i < currentString.length(); i++) {
            // takes the character at i
            char value = currentString.charAt(i);
            // checks if the value is 1 or not
            if (value == '1') {
                // adds 1 to the one count of the string
                onecount++;
            }
        }
        // converts the integer count to a string
        double fitness = onecount;
        // finishes the method
        return fitness;
    }
    // overides the mutation popualtin methd
    @Override
    // method for mutationg the population
    protected ArrayList<Character> mutatePopulation(ArrayList<Character> list) {

        // intialies the character look at
        char newLookAtValue = '0';
        // for loop to cycle through the list
        for (int i = 0; i < list.size(); i++) {
            // takes the character at i from the array list
            char lookAtValue = list.get(i);
            // genreats a random nmber between o and 1
            double randomMutation = Math.random();
            // checks if the random number genrated is below the mutation probalitity
            if (randomMutation <= PopulationStore.mutationProbability) {
                // remvoes the current vlaue from the list
                list.remove(i);
                // checks if the value is 1
                if (lookAtValue == '1') {
                    // changes the value to 0
                    newLookAtValue = '0';
                    //adds the value to the list
                    list.add(i, newLookAtValue);
                    // chekcs if the value is 0
                } else if (lookAtValue == '0') {
                    // creates the new mutated value
                    newLookAtValue = '0';
                    // adds the new value to the list
                    list.add(i, newLookAtValue);
                }
            }
        }
        // finsihes the mthod
        return list;
    }
    // overides the method
    @Override
    // runs the method
    protected void sortPopulation(ArrayList<String> list) {
        // sorts the list
        Collections.sort(list);
        
    }


}
































/*
    BinaryMaxmiser() {
        chromosomeSize = 4;
    }
    private static ArrayList<String> sort(ArrayList<String> list) {
        Colections.sort(list);
        return list;
    }

    // this should be a constructor
    public static ArrayList<Character> initialPopulationGeneration(int chromosomeSize, int numberOfChromosomes) {
        int chromosomeSize = binaryString;
        int numberOfChromosomes = 100;
        int genes = (numberOfChromosomes * chromosomeSize);

        // creates the new array probably needs to be moved to BinaryMaxmiser
        ArrayList<Character> binaryList = new ArrayList<Character>();
        int genesGenerated = 0;
        while(genesGenerated < (genes)) {
            double randomBinary = Math.random();
        if (randomBinary < 0.5) {
            binaryList.add('0');
        } else if (randomBinary >= 0.5) {
            binaryList.add('1');
        }
        genesGenerated++;
    }
    return binaryList;
    }

    public static void main(String[] args) {
        GAApplication algorithm = new GAApplication()
            GAApplication.run(chromosomeSize, binaryList);

    }
}
*/
