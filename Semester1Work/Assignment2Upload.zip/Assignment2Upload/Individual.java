package com.bham.pij.assignments.a2a;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Collections;
public class Individual {

    private ArrayList<Character> populationbinary;
    BinaryMaximiser individual = new BinaryMaximiser();
    FinalVariables start = new FinalVariables();
    //public char[] list = Individual();
    // BinaryMaximiser

    // method to convert charactes to strings
    BinaryMaximiser[] individualGene = new BinaryMaximiser[start.numberOfChromosomes];
    public Individual() {
        BinaryMaximiser[] individualGene = new BinaryMaximiser[start.numberOfChromosomes];
        for (int i = 0; i<start.numberOfChromosomes; i++) {
            individualGene[i] = new BinaryMaximiser(individual.generatedsize);
        }
    }
    public static String toString(ArrayList<Character> list) {
        // initialsises the string
        String convertedString = "";
        // for loop to run through the characters
        for (int i = 0; i < list.size(); i++) {
            // gets the character form the string
            char charToString = list.get(i);
            // creats the string
            convertedString = convertedString + charToString;
        }
        // finishes the method
        return convertedString;
    }
    public double getFitness() {

        double fitnessdouble = 0;
        for (int i = 0; i < individualGene[i].gene.size(); i++) {
            char currentChar = individualGene[i].gene.get(i);
            if (currentChar == '1') {
                fitnessdouble = fitnessdouble + 1;
            }
        }
        /*
        for (int i = 0; i < currentString.length(); i++) {
            char currentCharacter = currentString.charAt(i);
            if (currentCharacter == '1') {
                fitnessdouble = fitnessdouble + 1;
            }
        }
        */
        return fitnessdouble;
    }

}
